public static class Java{
    public static void main(String args[]){
        System.out.println("Hellow world");
    }
}